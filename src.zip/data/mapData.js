export const mapdata = [
  {
    _id: "1",
    position: "장소1",
    image:
      "https://trendsafari.co.kr/wp-content/uploads/2021/07/%EB%9D%BC%EC%9D%B4%EC%96%B8%EC%B6%98%EC%8B%9D%EC%9D%B4.png",
    lat: 37.6583599,
    lng: 126.8320201,
    date: "2023-01-20",
  },
  {
    _id: "2",
    position: "장소2",
    image:
      "https://trendsafari.co.kr/wp-content/uploads/2021/07/%EB%9D%BC%EC%9D%B4%EC%96%B8%EC%B6%98%EC%8B%9D%EC%9D%B4.png",
    lat: 37.5642135,
    lng: 127.0016985,
    date: "2023-01-21",
  },
  {
    _id: "3",
    position: "장소3",
    image:
      "https://trendsafari.co.kr/wp-content/uploads/2021/07/%EB%9D%BC%EC%9D%B4%EC%96%B8%EC%B6%98%EC%8B%9D%EC%9D%B4.png",
    lat: 37.44,
    lng: 126.766,
    date: "2023-01-22",
  },
  {
    _id: "4",
    position: "장소4",
    image:
      "https://trendsafari.co.kr/wp-content/uploads/2021/07/%EB%9D%BC%EC%9D%B4%EC%96%B8%EC%B6%98%EC%8B%9D%EC%9D%B4.png",
    lat: 37.4449168,
    lng: 127.1388684,
    date: "2023-01-23",
  },
  {
    _id: "5",
    position: "장소5",
    image:
      "https://trendsafari.co.kr/wp-content/uploads/2021/07/%EB%9D%BC%EC%9D%B4%EC%96%B8%EC%B6%98%EC%8B%9D%EC%9D%B4.png",
    lat: 37.2635727,
    lng: 127.0286009,
    date: "2023-01-24",
  },
];
